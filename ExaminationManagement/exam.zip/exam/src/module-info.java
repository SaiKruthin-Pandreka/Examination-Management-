/**
 * 
 */
/**
 * 
 */
module exam {
	requires java.sql;
}